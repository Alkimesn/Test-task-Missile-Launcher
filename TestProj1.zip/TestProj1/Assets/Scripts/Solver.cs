﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Solver
{
    public static Vector2 Solve(Func<float, Vector2> trajectory, Vector2 launcher, float speed, float launchtime)
    {
        Func<float, float> equation = t => (trajectory(t) - launcher).magnitude - speed * (t-launchtime);
        float t1 = launchtime;
        float t2 = t1;
        while (equation(t2) > 0&&t2<100) t2++;
        if (t2 > 100) throw new Exception();
        if (equation(t2) == 0) return trajectory(t2);
        float eps = 0.01f;
        while(t2-t1>eps)
        {
            float t = (t1 + t2) / 2;
            float res = equation(t);
            if (res == 0) return trajectory(t);
            if (res > 0) t1 = t; else t2 = t;
        }
        return trajectory((t1 + t2) / 2);
    }
}
