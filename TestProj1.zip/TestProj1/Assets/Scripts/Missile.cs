﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour
{
    float speed=50;
    public Vector3 target;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void Destroy()
    {
        Destroy(gameObject);
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        Vector3 shift = (target - transform.position).normalized * speed * Time.fixedDeltaTime;
        transform.position += shift;
    }
}
