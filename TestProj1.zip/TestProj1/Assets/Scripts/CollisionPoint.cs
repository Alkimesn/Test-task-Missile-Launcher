﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionPoint : MonoBehaviour
{
    public bool IsStopped = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public Camera cam;
    public bool OutOfBounds()
    {
        Vector2 pos = transform.position;
        var scrpos = cam.WorldToScreenPoint(pos);
        return (scrpos.x < 0 || scrpos.y < 0 || scrpos.x > cam.pixelWidth || scrpos.y > cam.pixelHeight);
    }
    public void Move(Vector2 vect)
    {
        if(!IsStopped)transform.position = vect;
    }
    public void Destroy()
    {
        Destroy(gameObject);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
