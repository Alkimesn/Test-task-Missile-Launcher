﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plane : MonoBehaviour
{
    public float MaxX = 100;
    public float MinX = -100;
    public float MaxY = 50;
    public float MinY = -50;
    public PlaneSpawner ps;
    public Transform launcher;
    public CollisionPoint collision;
    public Camera cam;
    public bool OutOfBounds()
    {
        Vector2 pos = transform.position;
        var scrpos = cam.WorldToScreenPoint(pos);
        return (scrpos.x < 0 || scrpos.y < 0 || scrpos.x > cam.pixelWidth || scrpos.y > cam.pixelHeight);
    }
    Trajectory tr;
    Vector3 oldposition;
    float tnow;
    // Start is called before the first frame update
    void Generate()
    {
        Vector2[] spawnpoints = new Vector2[4];
        spawnpoints[2] = cam.ScreenToWorldPoint(new Vector3(0, cam.pixelHeight / 2, 0));
        spawnpoints[0] = cam.ScreenToWorldPoint(new Vector3(cam.pixelWidth, cam.pixelHeight / 2, 0));
        spawnpoints[3] = cam.ScreenToWorldPoint(new Vector3(cam.pixelWidth / 2, 0, 0));
        spawnpoints[1] = cam.ScreenToWorldPoint(new Vector3(cam.pixelWidth / 2, cam.pixelHeight, 0));
        Vector2[] spawnspeeddirs = new Vector2[4];
        spawnspeeddirs[2] = Vector2.right + Vector2.up / 10;
        spawnspeeddirs[0] = Vector2.left + Vector2.down / 10;
        spawnspeeddirs[3] = Vector2.up + Vector2.right / 10;
        spawnspeeddirs[1] = Vector2.down + Vector2.left / 10;

        tnow = 0;
        int type = Random.Range(0, 5);
        float accel = Random.Range(-0.5f, 0.5f);
        float speed = Random.Range(10f, 20f);
        float width = spawnpoints[0].x * 2;
        float height = spawnpoints[1].y * 2;
        int start = Random.Range(0, 4);
        Vector2 startpos = spawnpoints[start];
        Vector2 speedvect = spawnspeeddirs[start] * speed;
        Vector2 accelvect = new Vector2(spawnspeeddirs[start].y, -spawnspeeddirs[start].x) * accel;
        if (type == 0) tr = Trajectory.UniformAccel(startpos+((start%2==1)?Random.Range(-width/3,width/3)*Vector2.left: Random.Range(-height / 3, height / 3) * Vector2.up), speedvect, ((start == 0 || start == 2) ? 3 : 1) * accelvect);
        if (type == 1)
        {
            Vector2 center = Vector2.zero;
            int dir = Random.Range(0, 2) * 2 - 1;
            tr = Trajectory.CircleAccel(speedvect.magnitude, accelvect.magnitude, center, (center - startpos).magnitude, start * Mathf.PI / 2, dir);
        }
        if (type == 2)
        {
            tr = Trajectory.UniformAccel(startpos + ((start % 2 == 1) ? Random.Range(-width / 3, width / 3) * Vector2.left : Random.Range(-height / 3, height / 3) * Vector2.up), speedvect, speedvect.normalized * accel);
        }
        if (type == 3)
        {
            Vector2 center = startpos;
            int dir = Random.Range(0, 2) * 2 - 1;
            tr = Trajectory.CircleAccel(speed, accel, center, spawnpoints[1].y * 2 / 3, dir * (start + 1) * Mathf.PI / 2, dir);
        }
        if(type==4)
        {
            if (Random.Range(0, 2) == 0) tr = Trajectory.SinusAccel(speed / 2, 0, height / 4, width / Random.Range(5,10), start % 2 == 0 ? spawnpoints[0] : spawnpoints[2], start % 2 == 0 ? -1 : 1);
            else tr = Trajectory.SinusAccel(speed / 2, 0, width / 5, height / Random.Range(5, 10), start % 2 == 0 ? spawnpoints[1] : spawnpoints[3], start % 2 == 0 ? -1 : 1,true);
        }
    }
    void Start()
    {
        Generate();
        tnow = 0;
        transform.position = tr.trajectory(0);
        oldposition = transform.position;
    }
    public void Destroy()
    {
        Destroy(gameObject);
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        tnow += Time.fixedDeltaTime;
        oldposition = transform.position;
        transform.position = tr.trajectory(tnow);
        transform.up = transform.position - oldposition;
        collision.Move(Solver.Solve(tr.trajectory, launcher.position, 50, tnow));
        if (OutOfBounds() || collision.OutOfBounds())
        {
            ps.Respawn();
        }
    }
}
