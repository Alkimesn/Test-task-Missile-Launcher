﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trajectory
{
    public Func<float, Vector2> trajectory;
    public static Trajectory UniformAccel(Vector2 start, Vector2 startspeed, Vector2 accel)
    {
        Trajectory tr = new Trajectory();
        tr.trajectory = t => start + t*startspeed+t*t*accel/2;
        return tr;
    }
    public static Trajectory CircleAccel(float speed, float tangaccel, Vector2 center, float radius, float startangle, int dir=1)
    {
        Trajectory tr = new Trajectory();
        Func<float, float> totalangle = t => dir*(speed / radius * t + tangaccel / radius * t * t / 2);
        tr.trajectory = t => new Vector2(Mathf.Cos(startangle + totalangle(t)), Mathf.Sin(startangle + totalangle(t))) * radius + center;
        return tr;
    }
    public static Trajectory SinusAccel(float xspeed, float xaccel, float yper, float xper, Vector2 start, int dir, bool swapxy=false)
    {
        Func<float, float> sin = x => Mathf.Sin(x * Mathf.PI * 2 / xper) * yper / 2;
        Func<float, float> x_t = t => xspeed * t + xaccel * t * t / 2;
        Trajectory tr = new Trajectory();
        if(!swapxy)tr.trajectory = t => new Vector2(start.x + dir * x_t(t), start.y + sin(x_t(t)));
        else tr.trajectory = t => new Vector2(start.x + sin(x_t(t)), start.y + dir * x_t(t));
        return tr;
    }
}
