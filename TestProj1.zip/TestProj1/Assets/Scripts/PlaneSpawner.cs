﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneSpawner : MonoBehaviour
{
    public Plane plorig;
    Plane pl;
    public CollisionPoint collisionorig;
    CollisionPoint collision;
    public Missile missileorig;
    Missile missile;
    bool IsMissileLaunched = false;
    public Camera cam;
    // Start is called before the first frame update
    void Start()
    {
        Respawn();
    }
    public void Respawn()
    {
        pl?.Destroy();
        if (missile != null) missile.Destroy();
        collision?.Destroy();
        IsMissileLaunched = false;
        collision = Instantiate(collisionorig);
        pl = Instantiate(plorig);
        pl.ps = this;
        pl.collision = collision;
        pl.cam = cam;
        collision.cam = cam;
        pl.launcher = gameObject.transform;
    }
    int PlanesDestroyed = 0;
    // Update is called once per frame
    void Update()
    {
        if (IsMissileLaunched)
        {
            //print((missile.transform.position - pl.transform.position).magnitude);
            if ((missile.transform.position - pl.transform.position).magnitude < 1)
            {
                PlanesDestroyed++;
                Respawn();
            }
        }
    }
    private void OnMouseOver()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (IsMissileLaunched) return;
            missile = Instantiate(missileorig);
            missile.transform.position = transform.position;
            missile.transform.right = collision.transform.position - missile.transform.position;
            missile.target = collision.transform.position;
            collision.IsStopped = true;
            IsMissileLaunched = true;
        }
    }
}
